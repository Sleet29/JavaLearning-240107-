package baek;
public class TestCow {
	public static void main(String args[]){
		System.out.println("(___)");
		System.out.println("(o o)____/");
		System.out.println(" @@      \\");
		System.out.println("  \\ ____,/");
		System.out.println("  //   //");
		System.out.println(" ^^   ^^");
		
    } 
}