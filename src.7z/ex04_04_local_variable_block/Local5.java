package ex04_04_local_variable_block;

public class Local5 {
	public static void main(String args[]) {
		int num=20;
		System.out.println("2=" + num);
		
		//int num=10; // Duplicate local variable num (중복 선언)
		System.out.println("1=" + num);
	}

}
