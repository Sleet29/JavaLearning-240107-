package ex05_1_if;
public class IfExample1_1 {
	public static void main(String args[]) {
		int num1 = 30;
		int num2 = 20;
		
		if( num1 > num2 ) {
			System.out.println("num1 값이 더 큽니다.");
			System.out.println("num1 = " + num1);
		}
		
		System.out.println("끝.");
	}

}
