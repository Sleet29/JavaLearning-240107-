package ex05_5_for;

public class ForExample3_loop {
	public static void main(String args[]) {
		//무한반복입니다.
		for (;;) // 초기치-조건식-증감식에 아무것도 대입하지 않을때
			System.out.println("집에 가고 싶어요~~~~~");
	}

}
