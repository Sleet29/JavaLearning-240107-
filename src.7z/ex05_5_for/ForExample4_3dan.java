package ex05_5_for;

public class ForExample4_3dan {
	public static void main(String args[]) {
		int i=2;
		int j;
		for(j=1;j<10;j++) {
			System.out.println(i+"*"+j+"="+i*j);
		}
	}
}