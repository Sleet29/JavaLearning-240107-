package ex05_5_for;

public class ForExample1_1 {
	public static void main(String args[]) {
		
		int cnt;
		for (cnt = 10;cnt>0;cnt--) {
			System.out.println(cnt);
		}
	}
}