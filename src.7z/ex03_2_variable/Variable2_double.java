package ex03_2_variable;

public class Variable2_double {
	public static void main(String args[]) {
		System.out.println("==============실수형 변수==============");
		// 실수형 변수
		// f나 F를 숫자 뒤에 붙인다.
		float ft = 3.14f;
				
		// d나 D를 숫자 뒤에 붙인다.
		double d = 42.195;
		
		System.out.println("f = " + ft+"\n" + "d = " + d);
	}
}