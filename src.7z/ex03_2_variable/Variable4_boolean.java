package ex03_2_variable;
public class Variable4_boolean {
	public static void main(String args[]) {
		System.out.println("==============논리형 변수==============");
		// 논리형 변수
		boolean b1 = true;
		boolean b2 = false;
		System.out.println("b1은 참인 " + b1);
		System.out.println("b2는 거짓인 " + b2);
		System.out.println('A' < 'a');
		// 아스키코드에서 'a'는 97의 값을 가지지만 'A'는 65의 값 가짐
		// 고로 참
	}

}
