package ex02_comment;
public class Test {
	public static void main(String args[]) {
		//한줄주석
		
		/*
		 * 
		 * 범 위 주 석
		 * 
		 */
		System.out.println("오늘도 화이팅!");
		System.out.println("좋아요!");
	}
}
