package ex03_1_literal;
public class SongJaeHyuk {

	public static void main(String args[]) {
		System.out.printf("%7s%s%n","1."," 이름 : 송재혁");
		System.out.printf("%7s%s%n","2."," E-Mail: wogurdl2570@gmail.com");
		System.out.printf("%7s%s%n","3."," 연락처: 010-2760-5929");
		System.out.printf("%7s%s%n","4."," 주소: 경기도 부천시");
		System.out.printf("%7s%s%n","5."," 보유 자격증: 운전면허증");
		System.out.printf("%7s%s%n","6."," 하고 싶은 말: 6개월 동안 잘 부탁드립니다!!");
		System.out.printf("%7s%s%n","7."," 사용해 본 언어: python,java,c++");
		System.out.printf("%7s%s%n","8."," 소요시간: 1시간");
		System.out.printf("%7s%s%n","9."," 각오 한마디 : 우수 수료를 노리겠습니다 +_+");
		System.out.printf("%8s%s%d%n","10."," 나의 간절함을 1부터 10까지 표현하면? : ",10);

		
	}
}
