package ex04_10_rel_logic_op;

public class CompExample1 {
	public static void main(String args[]) {
		System.out.println(3 < 4);
		System.out.println(10 > 20.0);
		System.out.println(12.5f <= 11);
		System.out.println(7 >= 7);
	}

}
