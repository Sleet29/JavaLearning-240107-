package ex05_6_break;

public class BreakExample2 {
	public static void main(String args[]) {
		int i,j;
		for(i=0;i<3;i++) {
			for(j=0;j<5;j++) {
				System.out.println("("+i+","+j+")");
			}
		}
			System.out.println("끝.");
	}
}