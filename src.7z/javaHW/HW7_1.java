package javaHW;

public class HW7_1 {
	public static void main(String args[]) {
		int i=-4;
		System.out.println("================= 2023년 12월 =================");
		while(++i <=31) {
			
		}
		System.out.println();
	}
}
