package ex04_07_concate_op;
// 문자열의 연결
public class Concate1_String {
	public static void main(String args[]) {
		String a = "퇴실";
		String b = " 꼭 찍어주세요";
		String c = a + b;
		System.out.println(c);
		
		String str = "결과값 : ";
		int n = 10;
		System.out.println(str + n);
	}

}
