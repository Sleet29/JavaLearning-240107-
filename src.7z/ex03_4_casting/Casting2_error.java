package ex03_4_casting;

public class Casting2_error {
	public static void main(String args[]) {
		
		// 오류 원인과 해결법은 무엇인가요?
		float ft = (float) 3.14;
		System.out.println(ft);
	}

}
