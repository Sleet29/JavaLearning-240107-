package ex03_4_casting;

public class Test_int_problem {
	public static void main(String args[]) {
		// 1. 정수형 변수(int) age에 자신의 나이를 저장합니다.
		
		
		// 출력문)
		// 2. 내 나이는 20입니다.
		
		
		// 3. 일년이 지나 내 나이는 한 살이 증가했습니다. (age의 변수 값을 1 증가합니다.)
		
		
		// 출력문)
		// 4. 내 나이는 21입니다.
		
		int age = 28;
		System.out.println("내 나이는 "+age+"입니다.");
		age = age + 1;
		System.out.println("내 나이는 "+age+"입니다.");
	}

}
