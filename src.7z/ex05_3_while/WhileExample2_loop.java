package ex05_3_while;

public class WhileExample2_loop {
	public static void main(String args[]) {
		while(true) {
			System.out.println("Hello, Java");
		}
	}
}