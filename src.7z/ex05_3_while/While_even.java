package ex05_3_while;

public class While_even {
		public static void main(String args[]) {
			int cnt =2 ;
			while (cnt<=10) {
				System.out.println(cnt);
				cnt +=2;
			}
	}
}