package ex05_3_while;

public class WhileExample0_before2 {
	public static void main(String args[]) {
		int cnt=0;
		
		while(cnt<10) {
			System.out.println(cnt++);
			//cnt +=1;
		}
	}

}
