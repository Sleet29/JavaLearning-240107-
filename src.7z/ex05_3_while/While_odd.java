package ex05_3_while;

public class While_odd {
	public static void main(String args[]) {
		int cnt = 1;
		while(cnt<10) {
			System.out.println(cnt);
			cnt+=2;
		}
	}

}
