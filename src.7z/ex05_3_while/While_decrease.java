package ex05_3_while;

public class While_decrease {
	public static void main(String args[]) {
		int num=9;
				
				while(num>=0) {
					System.out.println(num--);
				}
	}

}
