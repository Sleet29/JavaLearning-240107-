package ex07_10_method_call;
import java.util.*;
public class Numbers_make {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		int N = sc.nextInt();
		int[] arr = new int[N];
		
	}
	
	static void print() {
		System.out.println("배열명 : ");
	}

}
