package ex04_02_local_variable_init;

public class Local3 {
	public static void main(String args[]) {
		int num;
		// num이라는 변수를 선언
		num = 10 + 20;
		
		System.out.println(num);
	}

}
