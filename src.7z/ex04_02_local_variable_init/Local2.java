package ex04_02_local_variable_init;

public class Local2 {
	public static void main(String args[]) {
		int num;
		num = 10 + 20;
		//
		//local variable은 반드시 값을 넣어 주어야 사용할 수 있습니다.
		System.out.println(num);
	}

}
