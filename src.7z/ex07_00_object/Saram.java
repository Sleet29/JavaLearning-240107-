package ex07_00_object;

class Saram {
	// 필드 (멤버변수)
	String name;
	double w;
	double ki;
	int age;
	
	// 생성자
	// Saram(){}
	
	// 메서드
	public void eat() {
		System.out.println("밥을 먹는다.");
	}
	
	// 메서드
	public void walk() {
		System.out.println("걷는다.");
	}
	
	// 메서드
	public void sesu() {
		System.out.println("세수한다.");
	}
	
	
	
	public void sing() {
		System.out.println("노래한다.");
	}
	

}
