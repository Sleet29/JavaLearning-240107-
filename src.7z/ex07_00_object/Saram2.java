package ex07_00_object;

class Saram2 {
	// 필드 (멤버변수)
	String name;
	double w;
	double ki;
	int age;
	
	// 생성자
	// Saram(){}
	
	// 메서드
	public void eat() {
		System.out.println(name +"이(가) 밥을 먹는다.");
	}
	// name을 메서드 내에서 사용가능
	
	// 메서드
	public void walk() {
		System.out.println(name +"이(가) 걷는다.");
	}
	
	// 메서드
	public void sesu() {
		System.out.println(name + "이(가) 세수한다.");
	}
	
	
	
	public void sing() {
		System.out.println(name + "이(가) 노래한다.");
	}
	

}
