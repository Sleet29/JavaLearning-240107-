package ex01;

public class Test04 {
	public static void main(String args[]) {
		int arr[] = new int[5];
		arr[0] = 99;
		arr[1] = 85;
		arr[2] = 74;
		arr[3] = 68;
		arr[4] = 53;
		
		//for(arr : 5) {
			
		}
	}

