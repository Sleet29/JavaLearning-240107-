package ex01; //클래스 or 인터페이스 모음 폴더

/*
 1. main()을 포함하는 클래스의 파일명은 반드시 클래스명과 일치해야 한다.
 2. class 앞에 public이 붙으면 파일명은 바느시 클래스명과 일치해야 한다.
 */

public class Test1_public { // 클래스입니다.
	//접근제어자 - 객체생성없이 접근가능 반환되는 값의 자료형 메서드이름(매개변수 목록)
	public static void main(String args[]){ //메서드 입니다.
		System.out.println("안녕하세요~~!"); //화면에 출력되는 명령문입니다.
		System.out.println("안녕하세요~~!");
		System.out.println("안녕하세요~~!");
		System.out.println("안녕하세요~~!");
	}

}
