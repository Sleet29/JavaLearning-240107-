package ex01;


	class Test2_public_no{
		public static void main(String args[]) {
			System.out.println("Hello, Java~");
		}
}

