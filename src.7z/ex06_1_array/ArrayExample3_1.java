package ex06_1_array;

public class ArrayExample3_1 {
	public static void main(String args[]) {
		// 방법 3.
		System.out.println("===== 방법3 =====");
		
		int arr[] = {10,20,30,40,50};
		for (int i=0;i<arr.length; i++) {
			System.out.println("arr["+i+"]"+"="+arr[i]);
		}
	}

}
