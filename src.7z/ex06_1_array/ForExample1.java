package ex06_1_array;

public class ForExample1 {
	public static void main(String args[]) {
		int arr[] = {10,20,30,40,50};
		
		for(int cnt = 0;cnt<arr.length;cnt++) {
			System.out.println(arr[cnt]);
		}
		System.out.println("End.");
	}
}
