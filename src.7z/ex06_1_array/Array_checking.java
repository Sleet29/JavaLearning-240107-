package ex06_1_array;

public class Array_checking {
	public static void main(String args[]) {
		int[] arr = {10,20,30,40,50};
		
		for(int i=0;i<5;i++) {
			System.out.println("arr["+i+"]="+arr[i]);
		}
	}

}
